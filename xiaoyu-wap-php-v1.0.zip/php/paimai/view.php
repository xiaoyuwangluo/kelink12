<?php
/**
 * 小宇网络 WAP建站系统 PHP版
 * paimai模块 - 内容页
 */
require_once __DIR__ . '/../includes/bootstrap.php';

class PaimaiViewPage extends WapPage {
    public function run() {
        $db = $this->db;
        $id = (int)($_GET['id'] ?? 0);
        if ($id <= 0) $this->showError('参数错误');
        $row = $db->getOne("SELECT * FROM WapPaimai WHERE id=?",[$id]);
        if (!$row) $this->showError('内容不存在');
        $db->execute("UPDATE WapPaimai SET hits=hits+1 WHERE id=?", [$id]);
        $this->strTitle = $row['title'];
        $this->showTop($this->strTitle);
        echo '<div class="subtitle">' . $this->ToHtm($row['title']) . '</div>';
        echo '<div class="info">时间:' . date('Y-m-d H:i', strtotime($row['addtime'])) . ' 点击:' . (int)$row['hits'] . '</div>';
        if (!empty($row['picurl'])) echo '<div class="pic"><img src="' . $this->ToHtm($row['picurl']) . '"/></div>';
        echo '<div class="content">' . $this->wapTool->ToWML($row['content'], $this->wmlVo) . '</div>';

        // 拍卖出价区：当前最高价、出价次数、最近出价、出价入口
        $top = $db->getOne("SELECT MAX(price) AS top, COUNT(*) AS cnt FROM WapPaimaiBid WHERE paimaiid=?", [$id]);
        $curTop = (int)($top['top'] ?? 0);
        $bidCount = (int)($top['cnt'] ?? 0);
        echo '<div class="bidbar">当前最高价:￥' . $curTop . ' 出价次数:' . $bidCount . ' ';
        echo '<a href="bid.php?classid=' . $this->classid . '&paimaiid=' . $id . '">我要出价</a></div>';
        if ($bidCount > 0) {
            $bids = $db->getAll("SELECT nickname,price,addtime FROM WapPaimaiBid WHERE paimaiid=? ORDER BY price DESC,id DESC LIMIT 5", [$id]);
            echo '<div class="bidlist">最近出价:<br/>';
            foreach ($bids as $b) {
                echo $this->ToHtm($b['nickname']) . ' ￥' . (int)$b['price'] . ' ' . date('m-d H:i', strtotime($b['addtime'])) . '<br/>';
            }
            echo '</div>';
        }

        if (!empty($row['downurl'])) echo '<div class="download"><a href="' . $this->http_start . 'down.php?id=' . $id . '">下载</a></div>';
        echo '<div class="replybar"><a href="book_re.php?classid=' . $this->classid . '&id=' . $id . '">评论</a> ';
        echo '<a href="list.php?classid=' . $this->classid . '">返回列表</a></div>';
        $this->showDown();
    }
}
$page = new PaimaiViewPage();
$page->run();
