<%
response.redirect "index.htm"
%>
